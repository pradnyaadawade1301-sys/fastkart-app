// lib/screens/grocery/grocery_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../models/app_models.dart';
import '../cart/checkout_screen.dart';

// ─── Product Model ────────────────────────────────────────────────────────────
class GroceryProduct {
  final String id;
  final String name;
  final String source;
  final double rating;
  final int reviewCount;
  final String tags;
  final int deliveryMin;
  final int price;
  final int? originalPrice;
  final String emoji;
  final String category;
  final String? badge;
  final Color? badgeColor;

  const GroceryProduct({
    required this.id,
    required this.name,
    required this.source,
    required this.rating,
    required this.reviewCount,
    required this.tags,
    required this.deliveryMin,
    required this.price,
    this.originalPrice,
    required this.emoji,
    required this.category,
    this.badge,
    this.badgeColor,
  });
}

// ─── All Products ─────────────────────────────────────────────────────────────
const List<GroceryProduct> _allProducts = [
  // Vegetables
  GroceryProduct(id: 'g1', name: 'Fresh Tomatoes', source: 'Local farm sourced',
    rating: 4.7, reviewCount: 2100, tags: 'Farm fresh • Organic • 1 kg',
    deliveryMin: 10, price: 40, originalPrice: 60, emoji: '🍅',
    category: 'Vegetables', badge: 'Fresh', badgeColor: Color(0xFF2E7D32)),
  GroceryProduct(id: 'g2', name: 'Onions', source: 'Nashik farms',
    rating: 4.5, reviewCount: 3200, tags: 'Farm sourced • Sorted • 1 kg',
    deliveryMin: 10, price: 35, originalPrice: 50, emoji: '🧅',
    category: 'Vegetables', badge: 'Daily Fresh', badgeColor: Color(0xFF00897B)),
  GroceryProduct(id: 'g3', name: 'Potatoes', source: 'UP farms',
    rating: 4.4, reviewCount: 4500, tags: 'Washed & cleaned • 1 kg',
    deliveryMin: 10, price: 30, emoji: '🥔',
    category: 'Vegetables', badge: 'Bestseller', badgeColor: Color(0xFF5D4037)),
  GroceryProduct(id: 'g4', name: 'Spinach', source: 'Local farm',
    rating: 4.6, reviewCount: 1800, tags: 'Tender leaves • 500g bunch',
    deliveryMin: 10, price: 25, originalPrice: 40, emoji: '🥬',
    category: 'Vegetables', badge: 'Organic', badgeColor: Color(0xFF2E7D32)),
  // Fruits
  GroceryProduct(id: 'g5', name: 'Bananas', source: 'Kerala farms',
    rating: 4.8, reviewCount: 5600, tags: 'Ripe & sweet • 1 dozen',
    deliveryMin: 10, price: 60, originalPrice: 80, emoji: '🍌',
    category: 'Fruits', badge: 'Popular', badgeColor: Color(0xFFFF9800)),
  GroceryProduct(id: 'g6', name: 'Apples (Shimla)', source: 'Himachal farms',
    rating: 4.7, reviewCount: 3400, tags: 'Crispy & fresh • 1 kg',
    deliveryMin: 10, price: 120, originalPrice: 150, emoji: '🍎',
    category: 'Fruits', badge: 'Premium', badgeColor: Color(0xFFE53935)),
  GroceryProduct(id: 'g7', name: 'Mangoes (Alphonso)', source: 'Ratnagiri, Maharashtra',
    rating: 4.9, reviewCount: 2100, tags: 'King of fruits • 1 kg',
    deliveryMin: 10, price: 280, originalPrice: 350, emoji: '🥭',
    category: 'Fruits', badge: 'Seasonal', badgeColor: Color(0xFFFF9800)),
  // Dairy
  GroceryProduct(id: 'g8', name: 'Full Cream Milk', source: 'Amul dairy',
    rating: 4.8, reviewCount: 8900, tags: 'Pasteurized • 1 litre',
    deliveryMin: 10, price: 65, emoji: '🥛',
    category: 'Dairy', badge: 'Daily Fresh', badgeColor: Color(0xFF1565C0)),
  GroceryProduct(id: 'g9', name: 'Paneer', source: 'Mother Dairy',
    rating: 4.7, reviewCount: 5100, tags: 'Soft & fresh • 200g',
    deliveryMin: 10, price: 85, originalPrice: 100, emoji: '🧀',
    category: 'Dairy', badge: 'Fresh', badgeColor: Color(0xFF2E7D32)),
  GroceryProduct(id: 'g10', name: 'Curd', source: 'Nestle farms',
    rating: 4.6, reviewCount: 3800, tags: 'Thick & creamy • 400g',
    deliveryMin: 10, price: 45, emoji: '🍶',
    category: 'Dairy', badge: 'Probiotic', badgeColor: Color(0xFF7B1FA2)),
  // Staples
  GroceryProduct(id: 'g11', name: 'Basmati Rice', source: 'Punjab farms',
    rating: 4.8, reviewCount: 6700, tags: 'Long grain • Extra fragrant • 5kg',
    deliveryMin: 10, price: 450, originalPrice: 520, emoji: '🍚',
    category: 'Staples', badge: 'Premium', badgeColor: Color(0xFFFF9800)),
  GroceryProduct(id: 'g12', name: 'Toor Dal', source: 'Maharashtra farms',
    rating: 4.5, reviewCount: 3100, tags: 'Clean & sorted • 1 kg',
    deliveryMin: 10, price: 140, emoji: '🫘',
    category: 'Staples', badge: 'Clean', badgeColor: Color(0xFFE53935)),
  GroceryProduct(id: 'g13', name: 'Sunflower Oil', source: 'Marico',
    rating: 4.4, reviewCount: 2800, tags: 'Refined • Heart healthy • 1L',
    deliveryMin: 10, price: 130, originalPrice: 150, emoji: '🌻',
    category: 'Staples', badge: 'Refined', badgeColor: Color(0xFFFFB300)),
  GroceryProduct(id: 'g14', name: 'Atta (Whole Wheat)', source: 'Aashirvaad',
    rating: 4.7, reviewCount: 9200, tags: 'Stone ground • 5 kg',
    deliveryMin: 10, price: 280, originalPrice: 320, emoji: '🌾',
    category: 'Staples', badge: 'Bestseller', badgeColor: Color(0xFF5D4037)),
];

const List<String> _categories = ['All', 'Vegetables', 'Fruits', 'Dairy', 'Staples'];
const _green  = Color(0xFF00897B);
const _orange = Color(0xFFFF6B00);

// ─── Main Screen ──────────────────────────────────────────────────────────────
class GroceryHomeScreen extends StatefulWidget {
  const GroceryHomeScreen({super.key});
  @override
  State<GroceryHomeScreen> createState() => _GroceryHomeScreenState();
}

class _GroceryHomeScreenState extends State<GroceryHomeScreen> {
  int _selectedCategory = 0;
  final Map<String, int> _cart = {};

  List<GroceryProduct> get _filtered {
    if (_selectedCategory == 0) return _allProducts;
    final cat = _categories[_selectedCategory];
    return _allProducts.where((p) => p.category == cat).toList();
  }

  int get _totalItems => _cart.values.fold(0, (a, b) => a + b);
  int get _totalPrice => _cart.entries.fold(0, (sum, e) {
    final p = _allProducts.firstWhere((p) => p.id == e.key);
    return sum + p.price * e.value;
  });

  void _add(String id) => setState(() => _cart[id] = (_cart[id] ?? 0) + 1);
  void _remove(String id) => setState(() {
    if ((_cart[id] ?? 0) > 1) {
      _cart[id] = _cart[id]! - 1;
    } else {
      _cart.remove(id);
    }
  });

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7),
      body: Column(
        children: [
          _Header(
            selectedCategory: _selectedCategory,
            onCategoryTap: (i) => setState(() => _selectedCategory = i),
            onBack: () => context.pop(),
          ),
          // Promo banner
          Container(
            margin: const EdgeInsets.fromLTRB(14, 14, 14, 0),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: _green,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text('🛒', style: TextStyle(fontSize: 22)),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Free delivery on ₹299+',
                      style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
                  Text('Use code: FRESHKART',
                      style: TextStyle(color: Colors.white70, fontSize: 11)),
                ]),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('Grab',
                    style: TextStyle(color: _green, fontSize: 12, fontWeight: FontWeight.w800)),
              ),
            ]),
          ),
          // Category pills
          Container(
            margin: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: List.generate(_categories.length, (i) {
                  final sel = _selectedCategory == i;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedCategory = i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
                      decoration: BoxDecoration(
                        color: sel ? _green : Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: sel
                            ? [BoxShadow(color: _green.withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 3))]
                            : [],
                      ),
                      child: Text(_categories[i],
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: sel ? Colors.white : Colors.grey[700],
                          )),
                    ),
                  );
                }),
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Products list
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.fromLTRB(14, 0, 14, _totalItems > 0 ? 90 : 20),
              itemCount: filtered.length,
              itemBuilder: (_, i) => _ProductCard(
                product: filtered[i],
                qty: _cart[filtered[i].id] ?? 0,
                onAdd: () => _add(filtered[i].id),
                onRemove: () => _remove(filtered[i].id),
                onOrderNow: () => _showQuickOrder(context, filtered[i]),
              ),
            ),
          ),
        ],
      ),
      // Cart bar
      bottomNavigationBar: _totalItems > 0
          ? SafeArea(
              child: Container(
                margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
                decoration: BoxDecoration(
                  color: _green,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: _green.withValues(alpha: 0.4), blurRadius: 12, offset: const Offset(0, 4))],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      final cartItems = _cart.entries.map((e) {
                        final p = _allProducts.firstWhere((p) => p.id == e.key);
                        return CartItem(
                          food: FoodItem(
                            id: p.id,
                            name: p.name,
                            description: p.tags,
                            imageUrl: '',
                            price: p.price.toDouble(),
                            category: p.category,
                            restaurantId: 'grocery',
                          ),
                          quantity: e.value,
                        );
                      }).toList();
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CheckoutScreen(
                            restaurantId: 'grocery',
                            restaurantName: 'Grocery Store',
                            restaurantEmoji: '🛒',
                            restaurantImage: '',
                            items: cartItems,
                          ),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                      child: Row(children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.25),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text('$_totalItems item${_totalItems > 1 ? 's' : ''}',
                              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text('View Cart & Checkout',
                              style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
                        ),
                        Text('₹$_totalPrice',
                            style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
                        const SizedBox(width: 6),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white, size: 14),
                      ]),
                    ),
                  ),
                ),
              ),
            )
          : null,
    );
  }

  // ── Open Quick Order bottom sheet ─────────────────────────
  void _showQuickOrder(BuildContext context, GroceryProduct product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _QuickOrderSheet(product: product),
    );
  }
}

// ─── Header ───────────────────────────────────────────────────────────────────
class _Header extends StatelessWidget {
  final int selectedCategory;
  final ValueChanged<int> onCategoryTap;
  final VoidCallback onBack;
  const _Header({required this.selectedCategory, required this.onCategoryTap, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFE64A00), Color(0xFFFF6B00)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
              child: Row(children: [
                IconButton(
                  onPressed: onBack,
                  icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                ),
                const Spacer(),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: const Icon(Icons.notifications_none, color: Colors.white, size: 18),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              child: Column(children: [
                const Text('🏷️', style: TextStyle(fontSize: 40)),
                const SizedBox(height: 6),
                const Text('grocery',
                    style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic)),
                const Text('Explore grocery',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _Stat(value: '100+', label: 'Items'),
                      _VertDivider(),
                      _Stat(value: '50K+', label: 'Deliveries'),
                      _VertDivider(),
                      _Stat(value: '4.5 ⭐', label: 'Rating'),
                    ],
                  ),
                ),

              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String value;
  final String label;
  const _Stat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
    Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
  ]);
}

class _VertDivider extends StatelessWidget {
  const _VertDivider();
  @override
  Widget build(BuildContext context) =>
      Container(width: 1, height: 28, color: Colors.white.withValues(alpha: 0.3));
}

// ─── Product Card ─────────────────────────────────────────────────────────────
class _ProductCard extends StatelessWidget {
  final GroceryProduct product;
  final int qty;
  final VoidCallback onAdd;
  final VoidCallback onRemove;
  final VoidCallback onOrderNow; // ← NEW

  const _ProductCard({
    required this.product,
    required this.qty,
    required this.onAdd,
    required this.onRemove,
    required this.onOrderNow, // ← NEW
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          // Top section — image + details
          Container(
            decoration: BoxDecoration(
              color: _bgColor(product.category),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            ),
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.7),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(child: Text(product.emoji, style: const TextStyle(fontSize: 38))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(
                      child: Text(product.name,
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Color(0xFF1A1A1A))),
                    ),
                    if (product.badge != null)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: product.badgeColor ?? _green,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(product.badge!,
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
                      ),
                  ]),
                  const SizedBox(height: 4),
                  Row(children: [
                    const Icon(Icons.location_on, size: 11, color: Color(0xFF888888)),
                    const SizedBox(width: 2),
                    Text(product.source, style: const TextStyle(fontSize: 11, color: Color(0xFF888888))),
                  ]),
                  const SizedBox(height: 3),
                  Row(children: [
                    const Icon(Icons.star_rounded, size: 13, color: Color(0xFFFFA500)),
                    const SizedBox(width: 3),
                    Text('${product.rating}',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF555555), fontWeight: FontWeight.w700)),
                    const SizedBox(width: 3),
                    Text('(${_fmt(product.reviewCount)})',
                        style: const TextStyle(fontSize: 11, color: Color(0xFFBBBBBB))),
                  ]),
                ]),
              ),
            ]),
          ),
          // Bottom section — tags + price + buttons
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('🌿 ', style: TextStyle(fontSize: 11, color: Colors.green[700])),
                Expanded(child: Text(product.tags,
                    style: TextStyle(fontSize: 11, color: Colors.green[700], fontWeight: FontWeight.w600))),
              ]),
              const SizedBox(height: 3),
              Row(children: [
                const Icon(Icons.access_time, size: 11, color: Color(0xFF999999)),
                const SizedBox(width: 3),
                Text('${product.deliveryMin} min',
                    style: const TextStyle(fontSize: 11, color: Color(0xFF999999))),
              ]),
              const SizedBox(height: 10),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                // Price
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('₹${product.price}',
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _orange)),
                    if (product.originalPrice != null) ...[
                      const SizedBox(width: 6),
                      Text('₹${product.originalPrice}',
                          style: const TextStyle(
                              fontSize: 13, color: Color(0xFFAAAAAA),
                              decoration: TextDecoration.lineThrough)),
                    ],
                  ]),
                  const Text('per person', style: TextStyle(fontSize: 10, color: Color(0xFF999999))),
                ]),

                // ── Buttons row (Order Now + Add/Counter) ──────────
                Row(children: [
                  // Order Now button
                  _OrderNowBtn(onTap: onOrderNow),
                  const SizedBox(width: 8),
                  // Add / counter button
                  qty == 0
                      ? _AddBtn(onTap: onAdd)
                      : _CounterBtn(qty: qty, onAdd: onAdd, onRemove: onRemove),
                ]),
              ]),
            ]),
          ),
        ],
      ),
    );
  }

  Color _bgColor(String category) {
    switch (category) {
      case 'Vegetables': return const Color(0xFFE8F5E9);
      case 'Fruits':     return const Color(0xFFFFF3E0);
      case 'Dairy':      return const Color(0xFFE3F2FD);
      case 'Staples':    return const Color(0xFFFCE4EC);
      default:           return const Color(0xFFF5F5F5);
    }
  }

  String _fmt(int count) =>
      count >= 1000 ? '${(count / 1000).toStringAsFixed(1)}k' : '$count';
}

// ─── Order Now Button ─────────────────────────────────────────────────────────
class _OrderNowBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _OrderNowBtn({required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(24),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _green, width: 1.6),
            ),
            child: const Text('Order Now',
                style: TextStyle(color: _green, fontSize: 12, fontWeight: FontWeight.w800)),
          ),
        ),
      );
}

// ─── Add Button ───────────────────────────────────────────────────────────────
class _AddBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _AddBtn({required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
    color: _green,
    borderRadius: BorderRadius.circular(24),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: const Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Text('+ Add',
            style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
      ),
    ),
  );
}

// ─── Counter Button ───────────────────────────────────────────────────────────
class _CounterBtn extends StatelessWidget {
  final int qty;
  final VoidCallback onAdd;
  final VoidCallback onRemove;
  const _CounterBtn({required this.qty, required this.onAdd, required this.onRemove});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(24)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onRemove,
          borderRadius: const BorderRadius.horizontal(left: Radius.circular(24)),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Icon(Icons.remove, color: Colors.white, size: 16),
          ),
        ),
      ),
      Text('$qty',
          style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
      Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onAdd,
          borderRadius: const BorderRadius.horizontal(right: Radius.circular(24)),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Icon(Icons.add, color: Colors.white, size: 16),
          ),
        ),
      ),
    ]),
  );
}

// ─── Quick Order Bottom Sheet ─────────────────────────────────────────────────
class _QuickOrderSheet extends StatefulWidget {
  final GroceryProduct product;
  const _QuickOrderSheet({required this.product});

  @override
  State<_QuickOrderSheet> createState() => _QuickOrderSheetState();
}

class _QuickOrderSheetState extends State<_QuickOrderSheet> {
  final _formKey   = GlobalKey<FormState>();
  final _nameCtrl  = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _houseCtrl = TextEditingController();
  final _areaCtrl  = TextEditingController();
  final _cityCtrl  = TextEditingController();
  final _pinCtrl   = TextEditingController();

  String _addrType = 'Home';
  int    _qty      = 1;
  bool   _loading  = false;

  @override
  void dispose() {
    for (final c in [_nameCtrl, _phoneCtrl, _emailCtrl,
                     _houseCtrl, _areaCtrl, _cityCtrl, _pinCtrl]) {
      c.dispose();
    }
    super.dispose();
  }

  int get _total => widget.product.price * _qty;

  Future<void> _confirm() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Saare required fields bharo'),
        backgroundColor: Colors.red,
      ));
      return;
    }
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    setState(() => _loading = false);

    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('${widget.product.name} ka order place ho gaya! 🎉'),
      backgroundColor: _green,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    return Container(
      height: mq.size.height * 0.92,
      decoration: const BoxDecoration(
        color: Color(0xFFF5F5F5),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(children: [
        // Handle
        const SizedBox(height: 10),
        Container(width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
        const SizedBox(height: 4),

        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: Center(child: Text(widget.product.emoji,
                  style: const TextStyle(fontSize: 24))),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.product.name,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800,
                      color: Color(0xFF1A1A1A))),
              Text(widget.product.tags,
                  style: const TextStyle(fontSize: 11, color: Color(0xFF888888))),
            ])),
            IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.close_rounded, color: Color(0xFF888888)),
            ),
          ]),
        ),

        const Divider(height: 1, color: Color(0xFFE0E0E0)),

        // Form
        Expanded(
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
              children: [

                // Quantity
                _SheetCard(child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Quantity',
                        style: TextStyle(fontWeight: FontWeight.w700,
                            fontSize: 14, color: Color(0xFF1A1A1A))),
                    Row(children: [
                      _QtyBtn(icon: Icons.remove_rounded,
                          onTap: () { if (_qty > 1) setState(() => _qty--); }),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 18),
                        child: Text('$_qty', style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w900, color: _green))),
                      _QtyBtn(icon: Icons.add_rounded,
                          onTap: () => setState(() => _qty++)),
                    ]),
                  ],
                )),
                const SizedBox(height: 14),

                // Personal Details
                _label('Personal Details'),
                _SheetCard(child: Column(children: [
                  _SField(ctrl: _nameCtrl, label: 'Full Name',
                      icon: Icons.person_outline_rounded,
                      validator: (v) => v!.trim().isEmpty ? 'Naam daalo' : null),
                  _divider(),
                  _SField(ctrl: _phoneCtrl, label: 'Phone Number',
                      icon: Icons.phone_outlined,
                      type: TextInputType.phone,
                      formatters: [FilteringTextInputFormatter.digitsOnly,
                                   LengthLimitingTextInputFormatter(10)],
                      validator: (v) {
                        if (v!.trim().isEmpty) return 'Phone required hai';
                        if (v.trim().length != 10) return '10 digits chahiye';
                        return null;
                      }),
                  _divider(),
                  _SField(ctrl: _emailCtrl, label: 'Email (optional)',
                      icon: Icons.email_outlined,
                      type: TextInputType.emailAddress),
                ])),
                const SizedBox(height: 14),

                // Delivery Address
                _label('Delivery Address'),
                _SheetCard(child: Column(children: [
                  // Address type chips
                  Row(children: ['Home', 'Work', 'Other'].map((t) {
                    final sel = _addrType == t;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => _addrType = t),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
                          decoration: BoxDecoration(
                            color: sel ? _green.withValues(alpha: 0.10) : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: sel ? _green : const Color(0xFFE0E0E0),
                                width: sel ? 1.6 : 1),
                          ),
                          child: Text(
                            t == 'Home' ? '🏠 Home'
                                : t == 'Work' ? '💼 Work' : '📍 Other',
                            style: TextStyle(fontSize: 12,
                                fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                                color: sel ? _green : const Color(0xFF888888)),
                          ),
                        ),
                      ),
                    );
                  }).toList()),
                  const SizedBox(height: 12),
                  _SField(ctrl: _houseCtrl, label: 'House / Flat / Building',
                      icon: Icons.home_outlined,
                      validator: (v) => v!.trim().isEmpty ? 'Required' : null),
                  _divider(),
                  _SField(ctrl: _areaCtrl, label: 'Area / Street / Locality',
                      icon: Icons.location_city_outlined, maxLines: 2,
                      validator: (v) => v!.trim().isEmpty ? 'Required' : null),
                  _divider(),
                  Row(children: [
                    Expanded(child: _SField(ctrl: _cityCtrl, label: 'City',
                        icon: Icons.location_on_outlined, noBorder: true,
                        validator: (v) => v!.trim().isEmpty ? 'Required' : null)),
                    Container(width: 1, height: 48, color: const Color(0xFFE0E0E0)),
                    Expanded(child: _SField(ctrl: _pinCtrl, label: 'Pincode',
                        icon: Icons.pin_drop_outlined, noBorder: true,
                        type: TextInputType.number,
                        formatters: [FilteringTextInputFormatter.digitsOnly,
                                     LengthLimitingTextInputFormatter(6)],
                        validator: (v) {
                          if (v!.trim().isEmpty) return 'Required';
                          if (v.trim().length != 6) return '6 digits';
                          return null;
                        })),
                  ]),
                ])),
                const SizedBox(height: 14),

                // Price Summary
                _SheetCard(child: Column(children: [
                  _PriceRow('Price per item', '₹${widget.product.price}'),
                  const SizedBox(height: 6),
                  _PriceRow('Quantity', '× $_qty'),
                  const Divider(height: 20, color: Color(0xFFE0E0E0)),
                  _PriceRow('Total Payable', '₹$_total', bold: true, large: true),
                ])),
              ],
            ),
          ),
        ),

        // Confirm CTA
        Container(
          padding: EdgeInsets.fromLTRB(16, 12, 16, mq.padding.bottom + 12),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(
                color: Colors.black.withValues(alpha: 0.07),
                blurRadius: 10, offset: const Offset(0, -3))],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Total Payable',
                  style: TextStyle(fontSize: 13, color: Color(0xFF888888))),
              Text('₹$_total',
                  style: const TextStyle(fontSize: 20,
                      fontWeight: FontWeight.w900, color: _green)),
            ]),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity, height: 52,
              child: ElevatedButton(
                onPressed: _loading ? null : _confirm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _green,
                  disabledBackgroundColor: _green.withValues(alpha: 0.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 2,
                ),
                child: _loading
                    ? const SizedBox(width: 22, height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                    : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.shopping_bag_rounded, size: 18, color: Colors.white),
                        SizedBox(width: 8),
                        Text('Confirm Order',
                            style: TextStyle(fontSize: 15,
                                fontWeight: FontWeight.w800, color: Colors.white)),
                      ]),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _label(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 2),
      child: Text(t, style: const TextStyle(fontSize: 12,
          fontWeight: FontWeight.w800, color: Color(0xFF888888), letterSpacing: 0.3)));

  Widget _divider() =>
      const Divider(height: 1, thickness: 0.5, color: Color(0xFFE0E0E0));
}

// ─── Sheet Helpers ────────────────────────────────────────────────────────────
class _SheetCard extends StatelessWidget {
  final Widget child;
  const _SheetCard({required this.child});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity, padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8, offset: const Offset(0, 2))],
        ),
        child: child);
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 32, height: 32,
          decoration: BoxDecoration(color: const Color(0xFFE8F5E9),
              borderRadius: BorderRadius.circular(8)),
          child: Icon(icon, size: 18, color: _green)));
}

class _SField extends StatelessWidget {
  final TextEditingController ctrl;
  final String label;
  final IconData icon;
  final TextInputType type;
  final List<TextInputFormatter>? formatters;
  final int maxLines;
  final String? Function(String?)? validator;
  final bool noBorder;

  const _SField({
    required this.ctrl, required this.label, required this.icon,
    this.type = TextInputType.text, this.formatters, this.maxLines = 1,
    this.validator, this.noBorder = false,
  });

  @override
  Widget build(BuildContext context) => TextFormField(
        controller: ctrl, keyboardType: type,
        inputFormatters: formatters, maxLines: maxLines, validator: validator,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
            color: Color(0xFF1A1A1A)),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(fontSize: 12, color: Color(0xFF888888)),
          prefixIcon: Icon(icon, size: 18, color: const Color(0xFF888888)),
          border: InputBorder.none, enabledBorder: InputBorder.none,
          focusedBorder: noBorder ? InputBorder.none
              : const UnderlineInputBorder(
                  borderSide: BorderSide(color: _green, width: 1.5)),
          errorBorder: InputBorder.none, focusedErrorBorder: InputBorder.none,
          errorStyle: const TextStyle(fontSize: 10, color: Colors.red),
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        ));
}

class _PriceRow extends StatelessWidget {
  final String label, value;
  final bool bold, large;
  const _PriceRow(this.label, this.value,
      {this.bold = false, this.large = false});
  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(
              fontSize: large ? 15 : 13, color: const Color(0xFF888888))),
          Text(value, style: TextStyle(
              fontSize: large ? 17 : 13,
              fontWeight: bold ? FontWeight.w900 : FontWeight.w600,
              color: large ? _green : const Color(0xFF1A1A1A))),
        ]);
}